#pragma once

#include "BarChart.h"

#include "elements/Axis.h"
#include "elements/Key.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Histogram
//
////////////////////////////////////////////////////////////////////////////////////////////////////

class QDESIGNER_WIDGET_EXPORT Histogram : public BarChart
{
	Q_OBJECT

	Q_PROPERTY(QString title READ title WRITE setTitle)
	Q_PROPERTY(double xMin READ xMin WRITE setXMin)
	Q_PROPERTY(double xMax READ xMax WRITE setXMax)
	Q_PROPERTY(double xStep READ xStep WRITE setXStep)
	Q_PROPERTY(int xPrecision READ xPrecision WRITE setXPrecision)
	Q_PROPERTY(double yMax READ yMax WRITE setYMax)
	Q_PROPERTY(int yPrecision READ yPrecision WRITE setYPrecision)

	Q_PROPERTY(QColor color READ color0 WRITE setColor0)

	public:
		Histogram(QWidget *parent = 0);

		double xMin() const;
		void setXMin(double xMin);

		double xMax() const;
		void setXMax(double xMax);

		double xStep() const;
		void setXStep(double xStep);

		int xPrecision() const;
		void setXPrecision(int xPrecision);

		double yMax() const;
		void setYMax(double yMax);

		void setValue(int x, double value);
		void setAllValues(double value);
		double value(int x) const;

	private:
		void resetValues();
		void generateRandomValues();

		void updateNumberOfEntries();
		void paintEvent(QPaintEvent *);
		void paint(QPainter &painter);

		double m_xMin;
		double m_xMax;
		double m_xStep;
		int m_xPrecision;

		size_t m_numberOfEntries;

		std::vector<double> m_values;

		QRect m_chartRect;

		QFont m_font;
		QFontMetrics m_fontMetrics;
};
