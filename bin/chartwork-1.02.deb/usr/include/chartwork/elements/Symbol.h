#pragma once

#include <QRect>
#include <QFont>
#include <QFontMetrics>

class QPainter;

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Symbol
//
////////////////////////////////////////////////////////////////////////////////////////////////////

class Symbol
{
	public:
		enum Type
		{
			Circle,
			Square,
			Diamond,
			Plus,
			CircleOutline,
			SquareOutline,
			DiamondOutline,
			Cross
		};

		static void paint(QPainter &painter, QPoint center, int type, const QColor &color, int size);
};
