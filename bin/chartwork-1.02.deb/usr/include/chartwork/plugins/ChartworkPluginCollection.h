#pragma once

#include <QDesignerCustomWidgetCollectionInterface>

#include "GroupedBarChartPlugin.h"
#include "StackedBarChartPlugin.h"
#include "HistogramPlugin.h"
#include "GridChartPlugin.h"
#include "PieChartPlugin.h"
#include "ScatterPlotPlugin.h"
#include "LinePlotPlugin.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// ChartworkPluginCollection
//
////////////////////////////////////////////////////////////////////////////////////////////////////

class ChartworkPluginCollection : public QObject, public QDesignerCustomWidgetCollectionInterface
{
	Q_OBJECT
	Q_PLUGIN_METADATA(IID "ChartworkPluginCollectionInterface")
	Q_INTERFACES(QDesignerCustomWidgetCollectionInterface)

	public:
		QList<QDesignerCustomWidgetInterface *> customWidgets() const
		{
			return QList<QDesignerCustomWidgetInterface *>(
			{
				new PieChartPlugin,
				new GridChartPlugin,
				new GroupedBarChartPlugin,
				new StackedBarChartPlugin,
				new HistogramPlugin,
				new ScatterPlotPlugin,
				new LinePlotPlugin
			});
		}
};
