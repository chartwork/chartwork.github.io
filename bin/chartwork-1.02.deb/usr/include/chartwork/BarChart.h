#pragma once

#include "Chart.h"
#include "elements/Axis.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// BarChart
//
////////////////////////////////////////////////////////////////////////////////////////////////////

class QDESIGNER_WIDGET_EXPORT BarChart : public Chart
{
	Q_OBJECT

	public:
		BarChart(QWidget *parent = 0);

		double yMax() const;
		void setYMax(double yMax);

		int yPrecision() const;
		void setYPrecision(int yPrecision);

	protected:
		virtual void generateRandomValues() = 0;

		virtual void paintEvent(QPaintEvent *event) = 0;

		Axis m_yAxis;

		double m_yMax;
		int m_yPrecision;
};
