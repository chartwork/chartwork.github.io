#pragma once

#include <QtDesigner/QDesignerExportWidget>
#include <QWidget>

#include "ColorPalette.h"

#include "elements/Title.h"
#include "elements/Background.h"

////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Chart
//
////////////////////////////////////////////////////////////////////////////////////////////////////

class QDESIGNER_WIDGET_EXPORT Chart : public QWidget, public ColorPalette
{
	Q_OBJECT

	public:
		Chart(QWidget *parent = 0);

		const QString &title() const;
		void setTitle(const QString &title);

	public slots:
		void showContextMenu(const QPoint&);

	protected:
		virtual void paintEvent(QPaintEvent *event) = 0;
		void handleColorUpdate();

		virtual void handleValueUpdate();
		virtual void resetValues() = 0;

		Background m_background;
		Title m_title;

		bool m_isUntouched;
};
